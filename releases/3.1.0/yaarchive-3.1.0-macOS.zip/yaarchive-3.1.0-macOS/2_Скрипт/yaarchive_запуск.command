#!/bin/bash
# yaarchive — двойной щелчок (macOS): следить за этой папкой и обрабатывать новые пакеты расширения
cd "$(dirname "$0")"
PY=$(command -v python3)
if [ -z "$PY" ]; then
  echo "Не найден Python 3. Установите его с https://www.python.org/downloads/ (или: xcode-select --install) и запустите снова."
  read -p "Нажмите Enter…"; exit 1
fi
"$PY" yaarchive.pyz "$@"
